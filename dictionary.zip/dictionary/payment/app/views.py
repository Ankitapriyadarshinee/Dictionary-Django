from django.shortcuts import render
from pyDictionary import pyDictionary

# Create your views here.
def search(request):
    return render (request,'search.html')

def word(request):
    search = request.GET.get('search')
    dictionary = pyDictionary()
    meaning = dictionary.meaning(search)
    synonyms = dictionary. synonym(search)
    antonyms = dictionary.antonym(search)
    context = {
        'meaning' :meaning['Noun'][0],
        'synonyms':synonyms,
        'antonyms':antonyms,

    }
    return render(request,'word.html',context)


